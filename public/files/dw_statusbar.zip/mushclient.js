/**********************************************************************************
 * HP/GP/XP Status Bars                                                           *
 **********************************************************************************/
var HPRegenRate = 3;
var GPRegenRate = 3;

var barRedPercent = 0;
var barYellowPercent = 33;
var barGreenPercent = 66;
var barFullPercent = 100;
var barRed = "#ff0000";
var barYellow = "#ffff00";
var barGreen = "#00a000";
var barFull = "#00ff00";
var barBackground = "#808080";


var currentHP = 0;
var maxHP = 0;
var currentGP = 0;
var maxGP = 0;
var currentXP = 0;
var lastMXPGPValue = 0;
var lastMXPGPMaxValue = 0;
var lastMXPHPValue = 0;
var lastMXPHPMaxValue = 0;
var lastMXPXPValue = 0;

function handleMXPEntityChanges() {
	var update = false;
	var newHP = world.GetEntity("hp");
	if (newHP != lastMXPHPValue) {
		currentHP = parseInt(newHP);
		lastMXPHPValue = currentHP;
		update = true;
	}
	var newHPMax = world.GetEntity("maxhp");
	if (newHPMax != lastMXPHPMaxValue) {
		maxHP = parseInt(newHPMax);
		lastMXPHPMaxValue = maxHP;
		update = true;
	}
	var newGP = world.GetEntity("gp");
	if (newGP != lastMXPGPValue) {
		currentGP = parseInt(newGP);
		lastMXPGPValue = currentGP;
		update = true;
	}
	var newGPMax = world.GetEntity("maxgp");
	if (newGPMax != lastMXPGPMaxValue) {
		maxGP = parseInt(newGPMax);
		lastMXPGPMaxValue = maxGP;
		update = true;
	}
	var newXP = world.GetEntity("xp");
	if (newXP != lastMXPXPValue) {
		currentXP = parseInt(newXP);
		lastMXPXPValue = currentXP;
		update = true;
	}
	if (update) updateStatusBar();
}

function incrementGPHPOnHB() {
	if (currentGP < maxGP) {
		currentGP += GPRegenRate;
		if (currentGP > maxGP) currentGP = maxGP;
	}
	if (currentHP < maxHP) {
		currentHP += HPRegenRate;
		if (currentHP > maxHP) currentHP = maxHP;
	}
	currentXP += 3;
	updateStatusBar();
}

function createGraphicalBar(current, max, length) {
	if (max == 0) {
		world.Info("DIV_BY_ZERO");
		return;
	}
	var percentFull = (current/max)*100;
	world.InfoFont("Webdings", 10, 0);
	
	//What colour do we need to make this?
	var barColour;
	if (percentFull >= barFullPercent)
		barColour = barFull
	else if (percentFull >= barGreenPercent)
		barColour = barGreen;
	else if (percentFull >= barYellowPercent)
		barColour = barYellow;
	else
		barColour = barRed;

	var barString = "";
	var endString = "";
	
	//Length of the bar
	var barLength = Math.round(percentFull/100 * length);
	for (var i=0; i<barLength; i++) {
		barString += "g";
	}
	var endLength = length - barLength;
	for (var i=0; i<endLength; i++) {
		endString += "g";
	}
	
	if (barString.length) {
		world.InfoColour(barColour);
		world.Info(barString);
	}
	if (endString.length) {
		world.InfoColour(barBackground);
		world.Info(endString);
	}
}

function updateStatusBar() {
	world.InfoClear();
	
	//HP
	world.InfoColour("#000000");
	world.InfoFont("Arial", 10, 1);
	world.Info("Hp: ");
	
	world.InfoFont("Arial", 10, 0);
	world.Info(currentHP+"/"+maxHP+" [");
	
	createGraphicalBar(currentHP, maxHP, 5);
	
	world.InfoColour("#000000");
	world.InfoFont("Arial", 10, 0);
	world.Info("]  ");
	
	
	//GP
	world.InfoColour("#000000");
	world.InfoFont("Arial", 10, 1);
	world.Info("Gp: ");
	
	world.InfoFont("Arial", 10, 0);
	world.Info(currentGP+"/"+maxGP+" [");
	
	createGraphicalBar(currentGP, maxGP, 5);
	
	world.InfoColour("#000000");
	world.InfoFont("Arial", 10, 0);
	world.Info("]  ");
	
	
	//XP
	world.InfoColour("#000000");
	world.InfoFont("Arial", 10, 1);
	world.Info("Xp: ");
	
	world.InfoFont("Arial", 10, 0);
	world.Info(currentXP);
}

function handleSBOrMonitor(name,line,wildcards) {
	var m = /Hp: ?([0-9]+) ?\(([0-9]+)\) +Gp: ?([0-9]+) ?\(([0-9]+)\) +Xp: ?([0-9]+)/.exec(line);
	currentHP = parseInt(m[1]);
	maxHP = parseInt(m[2]);
	currentGP = parseInt(m[3]);
	maxGP = parseInt(m[4]);
	currentXP = parseInt(m[5]);
	
	updateStatusBar();
}

function handleScoreLineOne(name,line,wildcards) {
	var m = /You have ([0-9]+) \(([0-9]+)\) hit points, ([0-9]+) \(([0-9]+)\) guild points/.exec(line);
	currentHP = parseInt(m[1]);
	maxHP = parseInt(m[2]);
	currentGP = parseInt(m[3]);
	maxGP = parseInt(m[4]);
	updateStatusBar();
}

function handleScoreLineTwo(name,line,wildcards) {
	var m = /Your current experience is ([0-9]+)/.exec(line);
	currentXP = parseInt(m[1]);
	updateStatusBar();
}
/**********************************************************************************
 * END HP/GP/XP Status Bars                                                       *
 **********************************************************************************/